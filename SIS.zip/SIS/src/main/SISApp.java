package main;
import java.text.SimpleDateFormat;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import java.util.Scanner;
import java.util.Date;
import dao.*;
import entity.*;
import exception.CourseNotFoundException;
import exception.DuplicateEnrollmentException;
import exception.PaymentValidationException;
import exception.StudentNotFoundException;
import exception.TeacherNotFoundException;
import Util.*;

public class SISApp {

	private static final Scanner scanner = new Scanner(System.in);
    private static final ServiceProvider ServiceProvider = new ServiceProviderImpl();
    private static final StudentService StudentService = new StudentServiceImpl();
    private static final TeacherService TeacherService = new TeacherServiceImpl();
    private static final PaymentService PaymentService = new PaymentServiceImpl();
    private static final CourseService CourseService = new CourseServiceImpl();
    private static final EnrollmentService EnrollmentService = new EnrollmentServiceImpl();
    private static final sis sis = new SisImpl();

    public static void main(String[] args) throws SQLException, CourseNotFoundException {
        int choice;
        do {
            displayMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    StudentService();
                    break;
                case 2:
                    TeacherService();
                    break;
                case 3:
                    PaymentService();
                    break;
                case 4:
                	CourseService();
                	break;
                case 5:
                    EnrollmentService();
                    break;
                case 6:
                    sis();
                    break;
                case 7:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 7);
    }

	private static void sis() {
		int choice;
        do {
            sisMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	enrollStudentInCourse();
                    break;
                case 2:
                	assignTeacherToCourse();
                    break;
                case 3:
                	recordPayment();
                    break;
                case 4:
                	generateEnrollmentReport();
                	break;
                case 5:
                	generatePaymentReport();
                    break;
                case 6:
                	calculateCourseStatistics();
                    break;                
                case 7:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 6);		
	}

	public static void calculateCourseStatistics() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Course ID: ");
        int courseId = scanner.nextInt();

        Course course = new Course();
        course.setCourseID(courseId); // Assuming you have a method to set the course ID in the Course class

       sis.calculateCourseStatistics(course);

        System.out.println("Course statistics calculation process completed.");
    }
	public static void generatePaymentReport() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Student ID: ");
        int studentId = scanner.nextInt();

        Student student = new Student();
        student.setStudentID(studentId); // Assuming you have a method to set the student ID in the Student class

       sis.generatePaymentReport(student);

        System.out.println("Payment report generation process completed.");
    }

	

	    public static void generateEnrollmentReport() {
	        Scanner scanner = new Scanner(System.in);

	        System.out.print("Enter Course ID: ");
	        int courseId = scanner.nextInt();

	        Course course = new Course();
	        course.setCourseID(courseId); // Assuming you have a method to set the course ID in the Course class

	        sis.generateEnrollmentReport(course);

	        System.out.println("Enrollment report generation process completed.");
	    }



	private static void recordPayment() {
	    System.out.print("Enter Student ID: ");
	    int studentId = scanner.nextInt();
	    System.out.print("Enter Payment Amount: ");
	    double amount = scanner.nextDouble();
	    System.out.print("Enter Payment Date (YYYY-MM-DD): ");
	    String paymentDateString = scanner.next();

	    Student student = new Student();
	    student.setStudentID(studentId); // Assuming you have a method to set the student ID in the Student class

	    Date paymentDate;
	    try {
	        paymentDate = new SimpleDateFormat("yyyy-MM-dd").parse(paymentDateString);
	    } catch (ParseException e) {
	        System.out.println("Invalid date format. Please use yyyy-MM-dd.");
	        return;
	    }

	 sis.recordPayment(student, amount, paymentDate);

	    System.out.println("Payment recording process completed.");
	}


	private static void assignTeacherToCourse() {
	    System.out.print("Enter Teacher's First Name: ");
	    String firstName = scanner.next();
	    System.out.print("Enter Teacher's Last Name: ");
	    String lastName = scanner.next();
	    System.out.print("Enter Course ID: ");
	    int courseId = scanner.nextInt();

	    Teacher teacher = new Teacher();
	    teacher.setFirstName(firstName);
	    teacher.setLastName(lastName);

	    Course course = new Course();
	    course.setCourseID(courseId); // Assuming you have a method to set the course ID in the Course class

	    sis.assignTeacherToCourse(teacher, course);

	    System.out.println("Assignment process completed.");
	}




	private static void enrollStudentInCourse() {
	    System.out.print("Enter Student ID: ");
	    int studentId = scanner.nextInt();
	    System.out.print("Enter Course ID: ");
	    int courseId = scanner.nextInt();

	    Student student = new Student();
	    student.setStudentID(studentId); // Assuming you have a method to set the student ID in the Student class

	    Course course = new Course();
	    course.setCourseID(courseId); // Assuming you have a method to set the course ID in the Course class

	    sis.enrollStudentInCourse(student, course);

	    System.out.println("Enrollment process completed.");
	}


	private static void sisMenu() {
		System.out.println("===== Welcome to Quick Services =====");
        System.out.println("1. Enroll Student In Course");
        System.out.println("2. Assign Teacher to Course");
        System.out.println("3. Make Payment");
        System.out.println("4. View Enrollment Information");
        System.out.println("5. View Payment Information");
        System.out.println("6. Course Statistics");
        System.out.println("7. Exit");		
	}

	private static void EnrollmentService() {
		int choice;
        do {
            EnrollmentMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	getStudents();
                    break;
                case 2:
                	getCourse();
                    break;
                case 3:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 3);			
	}
	private static void getCourse() {
	    System.out.print("Enter Enrollment ID: ");
	    int enrollmentId = scanner.nextInt();

	    Enrollment enrollment = new Enrollment();
	    enrollment.setEnrollmentID(enrollmentId); // Assuming you have a method to set the enrollment ID in the Enrollment class

	    Course course = EnrollmentService.getCourse(enrollment);

	    if (course != null) {
	        System.out.println("Course Information for Enrollment ID " + enrollmentId + ":");
	        System.out.println("Course ID: " + course.getCourseID());
	        System.out.println("Course Name: " + course.getCourseName());
	        System.out.println("Credits: " + course.getCredits());
	        // Display other properties as needed
	    } else {
	        System.out.println("No course found for Enrollment ID " + enrollmentId);
	    }
	}


	private static void getStudents() {
	    System.out.print("Enter Enrollment ID: ");
	    int enrollmentId = scanner.nextInt();

	    Enrollment enrollment = new Enrollment();
	    enrollment.setEnrollmentID(enrollmentId); // Assuming you have a method to set the enrollment ID in the Enrollment class

	    Student student = EnrollmentService.getStudents(enrollment);

	    if (student != null) {
	        System.out.println("Student Information for Enrollment ID " + enrollmentId + ":");
	        System.out.println("Student ID: " + student.getStudentID());
	        System.out.println("First Name: " + student.getFirstName());
	        System.out.println("Last Name: " + student.getLastName());
	        System.out.println("Date of Birth: " + student.getDateOfBirth());
	        System.out.println("Email: " + student.getEmail());
	        System.out.println("Phone Number: " + student.getPhoneNumber());
	        // Display other properties as needed
	    } else {
	        System.out.println("No student found for Enrollment ID " + enrollmentId);
	    }
	}


	private static void EnrollmentMenu() {
		System.out.println("===== Welcome to Enrollment Services =====");
        System.out.println("1. View Assigned Student");
        System.out.println("2. View Assigned Course");
        System.out.println("3. Exit");		
	}

	private static void CourseService() throws CourseNotFoundException {
		int choice;
        do {
            CourseMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	assignTeacher();
                    break;
                case 2:
                	updateCourseInfo();
                    break;
                case 3:
                	displayCourseInfo();
                    break;
                case 4:
                	getEnrollments();
                	break;
                case 5:
                	getTeacher();
                    break;
                case 6:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 6);		
	}

	private static void getTeacher() {
	    System.out.print("Enter Course ID: ");
	    int courseId = scanner.nextInt();

	    Course course = new Course();
	    course.setCourseID(courseId); // Assuming you have a method to set the course ID in the Course class

	    Teacher teacher = CourseService.getTeacher(course);

	    if (teacher != null) {
	        System.out.println("Teacher Information for Course ID " + courseId + ":");
	        System.out.println("Teacher ID: " + teacher.getTeacherID());
	        System.out.println("First Name: " + teacher.getFirstName());
	        System.out.println("Last Name: " + teacher.getLastName());
	        System.out.println("Email: " + teacher.getEmail());
	        // Display other properties as needed
	    } else {
	        System.out.println("No teacher found for Course ID " + courseId);
	    }
	}


	private static void getEnrollments() {
	    System.out.print("Enter Course ID: ");
	    int courseId = scanner.nextInt();

	    Course course = new Course();
	    course.setCourseID(courseId); // Assuming you have a method to set the course ID in the Course class

	    List<Student> enrolledStudents = CourseService.getEnrollments(course);

	    if (!enrolledStudents.isEmpty()) {
	        System.out.println("Enrolled Students for Course ID " + courseId + ":");
	        for (Student student : enrolledStudents) {
	            System.out.println("Student ID: " + student.getStudentID());
	            System.out.println("First Name: " + student.getFirstName());
	            System.out.println("Last Name: " + student.getLastName());
	            System.out.println("Date of Birth: " + student.getDateOfBirth());
	            System.out.println("Email: " + student.getEmail());
	            System.out.println("Phone Number: " + student.getPhoneNumber());
	            // Display other properties as needed
	            System.out.println("--------------");
	        }
	    } else {
	        System.out.println("No enrolled students found for Course ID " + courseId);
	    }
	}


	private static void displayCourseInfo() {
	    System.out.print("Enter Course ID: ");
	    int courseId = scanner.nextInt();

	    Course course = new Course();
	    course.setCourseID(courseId); // Assuming you have a method to set the course ID in the Course class

	    CourseService.displayCourseInfo(course);
	}

	private static void updateCourseInfo() {
	    System.out.print("Enter Course ID: ");
	    int courseId = scanner.nextInt();
	    
	    System.out.print("Enter New Course Name: ");
	    String newCourseName = scanner.next();
	    System.out.print("Enter Credits: ");
	    int newcourseCredits = scanner.nextInt();
	    
	    Course course = new Course();
	    course.setCourseID(courseId); // Assuming you have a method to set the course ID in the Course class

	    CourseService.updateCourseInfo(course, newCourseName,newcourseCredits );
	}


	private static void assignTeacher() throws CourseNotFoundException {
	    System.out.print("Enter Course ID: ");
	    int courseId = scanner.nextInt();
	    System.out.print("Enter Teacher ID: ");
	    int teacherId = scanner.nextInt();

	    Course course = new Course();
	    course.setCourseID(courseId); // Assuming you have a method to set the course ID in the Course class

	    Teacher teacher = new Teacher();
	    teacher.setTeacherID(teacherId); // Assuming you have a method to set the teacher ID in the Teacher class

	    try {
			CourseService.assignTeacher(course, teacher);
		} catch (CourseNotFoundException | TeacherNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    System.out.println("Assignment process completed.");
	}


	private static void CourseMenu() {
		System.out.println("===== Welcome to Course Services =====");
        System.out.println("1. Assign Teacher");
        System.out.println("2. Update Course Information");
        System.out.println("3. View Course Information");
        System.out.println("4. View Course Enrollments");
        System.out.println("5. View Assigned Teacher");
        System.out.println("6. Exit");
		
	}

	private static void PaymentService() {
		int choice;
        do {
            PaymentsMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	getStudent();
                    break;
                case 2:
                	getPaymentAmount();
                    break;
                case 3:
                	getPaymentDate();
                    break;
                case 4:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 4);		
	}
	private static void getPaymentDate() {
	    System.out.print("Enter Payment ID: ");
	    int paymentId = scanner.nextInt();

	    Payment payment = new Payment();
	    payment.setPaymentID(paymentId); // Assuming you have a method to set the payment ID in the Payment class

	    Date paymentDate = PaymentService.getPaymentDate(payment);

	    if (paymentDate != null) {
	        System.out.println("Payment Date for Payment ID " + paymentId + ": " + paymentDate);
	    } else {
	        System.out.println("No payment date found for Payment ID " + paymentId);
	    }
	}


	private static void getPaymentAmount() {
	    System.out.print("Enter Payment ID: ");
	    int paymentId = scanner.nextInt();

	    Payment payment = new Payment();
	    payment.setPaymentID(paymentId); // Assuming you have a method to set the payment ID in the Payment class

	    double paymentAmount = PaymentService.getPaymentAmount(payment);

	    if (paymentAmount != 0.0) {
	        System.out.println("Payment Amount for Payment ID " + paymentId + ": " + paymentAmount);
	    } else {
	        System.out.println("No payment amount found for Payment ID " + paymentId);
	    }
	}


	

	private static void getStudent() {
	    System.out.print("Enter Payment ID: ");
	    int paymentId = scanner.nextInt();

	    Payment payment = new Payment();
	    payment.setPaymentID(paymentId); // Assuming you have a method to set the payment ID in the Payment class

	    Student student = PaymentService.getStudent(payment);

	    if (student != null) {
	        System.out.println("Student Information for Payment ID " + paymentId + ":");
	        System.out.println("Student ID: " + student.getStudentID());
	        System.out.println("First Name: " + student.getFirstName());
	        System.out.println("Last Name: " + student.getLastName());
	        // Display other properties as needed based on your database schema
	    } else {
	        System.out.println("No student found for Payment ID " + paymentId);
	    }
	}


	private static void PaymentsMenu() {
		System.out.println("===== Welcome to Payment Services =====");
        System.out.println("1. View Student Details");
        System.out.println("2. View Payment Amount");
        System.out.println("3. View Payment Date");
        System.out.println("4. Exit");			
	}

	private static void TeacherService() {
		int choice;
        do {
            TeacherMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	updateTeacherInfo();
                    break;
                case 2:
                	displayTeacherInfo();
                    break;
                case 3:
                	getAssignedCourses();
                    break;
                case 4:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 4);
		
	}

	private static void getAssignedCourses() {
	    System.out.print("Enter Teacher ID: ");
	    int teacherId = scanner.nextInt();

	    Teacher teacher = new Teacher();
	    teacher.setTeacherID(teacherId); // Assuming you have a method to set the teacher ID in the Teacher class

	    List<Course> assignedCourses = TeacherService.getAssignedCourses(teacher);

	    if (!assignedCourses.isEmpty()) {
	        System.out.println("Assigned Courses for Teacher ID " + teacherId + ":");
	        for (Course course : assignedCourses) {
	            System.out.println("Course ID: " + course.getCourseID());
	            System.out.println("Course Name: " + course.getCourseName());
	            System.out.println("Credits: " + course.getCredits());
	            
	            System.out.println("--------------");
	        }
	    } else {
	        System.out.println("No assigned courses found for Teacher ID " + teacherId);
	    }
	}

	

	private static void displayTeacherInfo() {
	    System.out.print("Enter Teacher ID: ");
	    int teacherId = scanner.nextInt();

	    Teacher teacher = new Teacher();
	    teacher.setTeacherID(teacherId); // Assuming you have a method to set the teacher ID in the Teacher class

	    TeacherService.displayTeacherInfo(teacher);
	}

	
	
			
	private static void updateTeacherInfo() {
	    System.out.print("Enter Teacher ID: ");
	    int teacherId = scanner.nextInt();
	    System.out.print("Enter New First Name: ");
	    String newFirstName = scanner.next();
	    System.out.print("Enter New Last Name: ");
	    String newLastName = scanner.next();
	    System.out.print("Enter New Email: ");
	    String newEmail = scanner.next();

	    Teacher teacher = new Teacher();
	    teacher.setTeacherID(teacherId); // Assuming you have a method to set the teacher ID in the Teacher class

	    String result = TeacherService.updateTeacherInfo(teacher, newFirstName, newLastName, newEmail);

	    if (result != null) {
	        System.out.println("Teacher information updated successfully!");
	    }
	}



	private static void TeacherMenu() {
		System.out.println("===== Welcome to Teacher Services =====");
        System.out.println("1. Update Teacher Information");
        System.out.println("2. View Teacher Information");
        System.out.println("3. View Assigned Courses");
        System.out.println("4. Exit");		
	}

	private static void StudentService() throws SQLException {
		int choice;
        do {
            StudentMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	enrollInCourse();
                    break;
                case 2:
                	updateStudentInfo();
                    break;
                case 3:
                	makePayment();
                    break;
                case 4:
                	displayStudentInfo();
                	break;
                case 5:
                	getEnrolledCourses();
                    break;
                case 6:
                	getPaymentHistory();
                    break;
                case 7:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 7);
		
	}

	
	private static void getPaymentHistory() {
	    System.out.print("Enter Student ID: ");
	    int studentId = scanner.nextInt();

	    Student student = new Student();
	    student.setStudentID(studentId); // Assuming you have a method to set the student ID in the Student class

	    List<Payment> paymentHistory = null;
		try {
			paymentHistory = StudentService.getPaymentHistory(student);
		} catch (PaymentValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    if (!paymentHistory.isEmpty()) {
	        System.out.println("Payment History for Student ID " + studentId + ":");
	        for (Payment payment : paymentHistory) {
	            System.out.println("Payment ID: " + payment.getPaymentID());
	            System.out.println("Amount: " + payment.getAmount());
	            System.out.println("Payment Date: " + payment.getPaymentDate());
	            System.out.println("--------------");
	        }
	    } else {
	        System.out.println("No payment history found for Student ID " + studentId);
	    }
	}


	private static void getEnrolledCourses() {
	    System.out.print("Enter Student ID: ");
	    int studentId = scanner.nextInt();

	    Student student = new Student(studentId, null, null, null, null, null);

	    List<Course> enrolledCourses = StudentService.getEnrolledCourses(student);

	    if (enrolledCourses != null && !enrolledCourses.isEmpty()) {
	        System.out.println("Enrolled Courses:");
	        for (Course course : enrolledCourses) {
	            System.out.println(course.getCourseName());
	        }
	    } else {
	        System.out.println("No enrolled courses found for the student.");
	    }
	}


	private static void displayStudentInfo() {

	    System.out.print("Enter Student ID: ");
	    int studentId = scanner.nextInt();
	    Student student = new Student(studentId, null, null, null, null, null); 
	    StudentService.displayStudentInfo(student);
	    
	}


	private static void makePayment() throws SQLException {
	    System.out.print("Enter Student ID: ");
	    int studentId = scanner.nextInt();
	    System.out.print("Enter Payment Amount: ");
	    double amount = scanner.nextDouble();
	    
	    // Collect payment date input
	    System.out.print("Enter Payment Date (YYYY-MM-DD): ");
	    String paymentDateString = scanner.next();
	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    Date paymentDate;

	    try {
	        paymentDate = dateFormat.parse(paymentDateString);
	    } catch (ParseException e) {
	        System.out.println("Invalid date format. Please use yyyy-MM-dd.");
	        return;
	    }

	    // Assuming you have a StudentService class with a makePayment method that takes a Date parameter
	    
		String result = null;
		try {
			result = StudentService.makePayment(studentId, amount, paymentDate);
		} catch (StudentNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
if (result!=null) {
    System.out.println("Payment successful!");
}
	}




	private static void updateStudentInfo() {
	    System.out.print("Enter Student ID: ");
	    int studentId = scanner.nextInt();
	    System.out.print("Enter New First Name: ");
	    String newFirstName = scanner.next();
	    System.out.print("Enter New Last Name: ");
	    String newLastName = scanner.next();
	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    System.out.print("Enter New Date of Birth (YYYY-MM-DD): ");
	    String newDateOfBirthString = scanner.next();

	    Date newDateOfBirth;
	    try {
	        newDateOfBirth = dateFormat.parse(newDateOfBirthString);
	    } catch (ParseException e) {
	        System.out.println("Invalid date format. Please use yyyy-MM-dd.");
	        return;
	    }

	    System.out.print("Enter New Email: ");
	    String newEmail = scanner.next();
	    System.out.print("Enter New Phone Number: ");
	    String newPhoneNumber = scanner.next();

	    String result = StudentService.updateStudentInfo(studentId, newFirstName, newLastName, newDateOfBirth, newEmail, newPhoneNumber);

	    if (result!=null) {
	        System.out.println("Student information updated successfully!");
	    } 
	}


	private static void enrollInCourse() {
	    System.out.print("Enter Student Id: ");
	    int studentId = scanner.nextInt();
	    System.out.print("Enter Course Id: ");
	    int courseId = scanner.nextInt();

	    boolean result = false;
		try {
			result = StudentService.enrollInCourse(studentId, courseId);
		} catch (DuplicateEnrollmentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    if (result) {
	        System.out.println("Student enrolled in the course successfully!");
	    } else {
	        System.out.println("Failed to enroll student in the course. Please try again.");
	    }
	}

	private static void StudentMenu() {
		System.out.println("===== Welcome to Student Services =====");
        System.out.println("1. Enroll A Course");
        System.out.println("2. Update Student Information");
        System.out.println("3. Make Payment");
        System.out.println("4. View Student Information");
        System.out.println("5. Enrolled Courses");
        System.out.println("6. Payment History");
        System.out.println("7. Exit");
		
	}

	private static void displayMenu() {
        System.out.println("===== Student Information System =====");
        System.out.println("1. Student Services");
        System.out.println("2. Teacher Services");
        System.out.println("3. Payment Services");
        System.out.println("4. Course Services");
        System.out.println("5. Enrollment Services");
        System.out.println("6. Quick Services");
        System.out.println("7. Exit");
	}
}
