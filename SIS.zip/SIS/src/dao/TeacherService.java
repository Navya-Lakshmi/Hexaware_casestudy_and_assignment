package dao;

import java.util.Date;
import java.util.List;

import entity.Course;
import entity.Teacher;

public interface TeacherService  {
	String updateTeacherInfo(int teacherId, String name,String lastName, String email);
	 void displayTeacherInfo(Teacher teacher);
	 List<Course> getAssignedCourses(Teacher teacher);
	String updateTeacherInfo(int teacherId, String newFirstName, String newLastName, Date ndob,
			String newEmail, String newPhoneNumber);
	String updateTeacherInfo(Teacher teacher, String name, String lastName, String email);
	}
