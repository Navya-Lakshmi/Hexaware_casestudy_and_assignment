package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import entity.Course;
import entity.Payment;
import entity.Student;
import exception.DuplicateEnrollmentException;
import exception.PaymentValidationException;
import exception.StudentNotFoundException;

public class StudentServiceImpl implements StudentService {
	private Connection conn;
	public StudentServiceImpl() {
	
	conn = Util.DBConnUtil.getConnection();
	}
	
	
	@Override
	public boolean enrollInCourse(int studentId, int courseId) throws DuplicateEnrollmentException {
	    // Check if the student is already enrolled in the course
	    if (isEnrolled(studentId, courseId)) {
	        throw new DuplicateEnrollmentException("Student is already enrolled in the course.");
	    }

	    // If not enrolled, proceed with the enrollment
	    String enrollQuery = "INSERT INTO enrollments (student_id, course_id) VALUES (?, ?)";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(enrollQuery)) {
	        preparedStatement.setInt(1, studentId);
	        preparedStatement.setInt(2, courseId);

	        int rowsAffected = preparedStatement.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Student enrolled in the course successfully.");
	            return true;
	        } else {
	            System.out.println("Failed to enroll student in the course.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return false;
	}

	// Method to check if the student is already enrolled in the course
	private boolean isEnrolled(int studentId, int courseId) {
	    String checkEnrollmentQuery = "SELECT COUNT(*) AS count FROM enrollments WHERE student_id = ? AND course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(checkEnrollmentQuery)) {
	        preparedStatement.setInt(1, studentId);
	        preparedStatement.setInt(2, courseId);

	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            if (resultSet.next()) {
	                int count = resultSet.getInt("count");
	                return count > 0;
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return false;
	}

	
	

	@Override
	public String updateStudentInfo(int studentId, String firstName, String lastName, Date dateOfBirth, String email, String phoneNumber) {
	    
	    String updateQuery = "UPDATE students SET first_Name=?, last_Name=?, date_Of_Birth=?, email=?, phone_Number=? WHERE student_id=?";

	    try (PreparedStatement ps = conn.prepareStatement(updateQuery)) {
	        ps.setString(1, firstName);
	        ps.setString(2, lastName);
	        ps.setDate(3, new java.sql.Date(dateOfBirth.getTime()));
	        ps.setString(4, email);
	        ps.setString(5, phoneNumber);
	        ps.setInt(6, studentId);
	       //ps.setInt(6, student.getStudentID());

	        int rowsAffected = ps.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Student information updated successfully.");
	        } else {
	            System.out.println("Failed to update student information.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        
	    }
	    return null;
	}

	@Override
	public String makePayment(int studentId, double amount, Date paymentDate) throws StudentNotFoundException {
	    // Check if the student exists before making a payment
	    if (!isStudentExists(studentId)) {
	        throw new StudentNotFoundException("Student does not exist in the system.");
	    }

	    String insertQuery = "INSERT INTO payments (student_id, amount, payment_date) VALUES (?, ?, ?)";

	    try (PreparedStatement ps = conn.prepareStatement(insertQuery)) {
	        ps.setInt(1, studentId);
	        ps.setDouble(2, amount);
	        ps.setDate(3, new java.sql.Date(paymentDate.getTime()));

	        int rowsAffected = ps.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Payment recorded successfully.");
	        } else {
	            System.out.println("Failed to record payment.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return null;
	}

	// Method to check if the student exists
	private boolean isStudentExists(int studentId) {
	    String checkStudentQuery = "SELECT COUNT(*) AS count FROM students WHERE student_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(checkStudentQuery)) {
	        preparedStatement.setInt(1, studentId);

	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            if (resultSet.next()) {
	                int count = resultSet.getInt("count");
	                return count > 0;
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return false;
	}



	private int getStudentID() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public void displayStudentInfo(Student student) {
	    String selectQuery = "SELECT * FROM students WHERE student_id= ?";

	    try (PreparedStatement ps = conn.prepareStatement(selectQuery)) {
	        ps.setInt(1, student.getStudentID());

	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {
	            System.out.println("Student Information:");
	            System.out.println("Student ID: " + rs.getInt("student_id"));
	            System.out.println("First Name: " + rs.getString("first_Name"));
	            System.out.println("Last Name: " + rs.getString("last_Name"));
	            System.out.println("Date of Birth: " + rs.getDate("date_Of_Birth"));
	            System.out.println("Email: " + rs.getString("email"));
	            System.out.println("Phone Number: " + rs.getString("phone_Number"));
	        } else {
	            System.out.println("Student not found.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        
	    }
	}


	@Override
	public List<Course> getEnrolledCourses(Student student) {
	    List<Course> enrolledCourses = new ArrayList<>();
	    String selectQuery = "SELECT c.* FROM enrollments e " +
	                        "JOIN courses c ON e.course_id = c.course_id " +
	                        "WHERE e.student_id = ?";

	    try (PreparedStatement ps = conn.prepareStatement(selectQuery)) {
	        ps.setInt(1, student.getStudentID());

	        ResultSet rs = ps.executeQuery();

	        while (rs.next()) {
	            Course course = new Course();
	            course.setCourseID(rs.getInt("course_ID"));
	            course.setCourseName(rs.getString("course_Name"));
	            course.setCredits(rs.getInt("credits"));
	            course.setTeacherId(rs.getInt("teacher_id"));
	            enrolledCourses.add(course);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return enrolledCourses;
	}


	@Override
	public List<Payment> getPaymentHistory(Student student) throws PaymentValidationException {
	    List<Payment> paymentHistory = new ArrayList<>();
	    String selectQuery = "SELECT * FROM payments WHERE student_ID = ?";

	    try (PreparedStatement ps = conn.prepareStatement(selectQuery)) {
	        ps.setInt(1, student.getStudentID());

	        ResultSet rs = ps.executeQuery();

	        while (rs.next()) {
	            Payment payment = new Payment();
	            payment.setPaymentID(rs.getInt("payment_ID"));
	            payment.setStudentID(rs.getInt("student_ID"));
	            payment.setAmount(rs.getDouble("amount"));
	            payment.setPaymentDate(rs.getDate("payment_Date"));

	            // Perform payment validation checks
	            if (isInvalidPayment(payment)) {
	                throw new PaymentValidationException("Invalid payment found.");
	            }

	            paymentHistory.add(payment);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return paymentHistory;
	}

	// Method to perform payment validation checks
	private boolean isInvalidPayment(Payment payment) {
	    // Example: Check if the amount is negative or payment date is in the future
	    return payment.getAmount() < 0 || ((java.sql.Date) payment.getPaymentDate()).toLocalDate().isAfter(LocalDate.now());
	}

	@Override
	public boolean makePayment(int studentId, double amount) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean updateStudentInfo(int studentId, String firstName, String lastName, String newDateOfBirth,
			String email, String phoneNumber) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
