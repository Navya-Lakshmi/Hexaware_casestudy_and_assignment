package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import entity.Course;
import entity.Enrollment;
import entity.Student;

public class EnrollmentServiceImpl implements EnrollmentService{
	private Connection conn;
	public EnrollmentServiceImpl() {
		conn = Util.DBConnUtil.getConnection();
	}

	@Override
	public Student getStudents(Enrollment enrollment) {
	    Student student = null;
	    String selectStudentQuery = "SELECT * FROM students WHERE student_id = (SELECT student_id FROM enrollments WHERE enrollment_id = ?)";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectStudentQuery)) {
	        preparedStatement.setInt(1, enrollment.getEnrollmentID());

	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            if (resultSet.next()) {
	                // Create Student object
	                student = new Student();
	                student.setStudentID(resultSet.getInt("student_id"));
	                student.setFirstName(resultSet.getString("first_name"));
	                student.setLastName(resultSet.getString("last_name"));
	                student.setDateOfBirth(resultSet.getDate("date_of_birth").toLocalDate());
	                student.setEmail(resultSet.getString("email"));
	                student.setPhoneNumber(resultSet.getString("phone_number"));
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return student;
	}


	@Override
	public Course getCourse(Enrollment enrollment) {
	    Course course = null;
	    String selectCourseQuery = "SELECT * FROM courses WHERE course_id = (SELECT course_id FROM enrollments WHERE enrollment_id = ?)";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectCourseQuery)) {
	        preparedStatement.setInt(1, enrollment.getEnrollmentID());

	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            if (resultSet.next()) {
	                // Create Course object
	                course = new Course();
	                course.setCourseID(resultSet.getInt("course_id"));
	                course.setCourseName(resultSet.getString("course_name"));
	                course.setCredits(resultSet.getInt("credits"));
	                // You may want to set other properties based on your database schema
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return course;
	}


}
