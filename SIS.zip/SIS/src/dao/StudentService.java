package dao;

import java.util.Date;
import java.util.List;

import entity.Course;
import entity.Payment;
import entity.Student;
import exception.DuplicateEnrollmentException;
import exception.PaymentValidationException;
import exception.StudentNotFoundException;

public interface StudentService  {
	
	 boolean updateStudentInfo(int studentId, String firstName, String lastName, String newDateOfBirth, String email, String phoneNumber);
	 
	 void displayStudentInfo(Student student);
	 List<Course> getEnrolledCourses(Student student);
	 List<Payment> getPaymentHistory(Student student) throws PaymentValidationException;
	 boolean enrollInCourse(int studentId, int courseId ) throws DuplicateEnrollmentException;
	boolean makePayment(int studentId, double amount);
	String updateStudentInfo(int studentId, String firstName, String lastName, Date dateOfBirth, String email,
			String phoneNumber);
	String makePayment(int studentId, double amount, Date paymentDate) throws StudentNotFoundException;
	
	}
