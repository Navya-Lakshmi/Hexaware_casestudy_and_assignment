package dao;

import java.sql.Date;

import entity.Payment;
import entity.Student;

public interface PaymentService{
	 Student getStudent(Payment payment);
	 double getPaymentAmount(Payment payment);
	 Date getPaymentDate();
	Date getPaymentDate(Payment payment);
	
	}