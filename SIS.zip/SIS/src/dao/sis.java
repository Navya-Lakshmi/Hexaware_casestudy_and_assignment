package dao;

import java.util.Date;

import entity.Course;
import entity.Student;
import entity.Teacher;

public interface sis {
	 void enrollStudentInCourse(Student student, Course course);
	 void assignTeacherToCourse(Teacher teacher, Course course);
	 void recordPayment(Student student, double amount, Date paymentDate);
	 void generateEnrollmentReport(Course course);
	 void generatePaymentReport(Student student);
	 void calculateCourseStatistics(Course course);
	}
