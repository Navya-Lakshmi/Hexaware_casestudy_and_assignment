package dao;

import java.util.Date;
import java.util.List;

import entity.Course;
import entity.Enrollment;
import entity.Payment;
import entity.Student;
import entity.Teacher;

public class ServiceProviderImpl implements ServiceProvider{

	@Override
	public String updateStudentInfo(int studentId, String firstName, String lastName, Date dateOfBirth, String email,
			String phoneNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	

	@Override
	public void displayStudentInfo(Student student) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Course> getEnrolledCourses(Student student) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Payment> getPaymentHistory(Student student) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean enrollInCourse(int studentId, int courseId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String updateTeacherInfo(Teacher teacher, String name, String lastName, String email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void displayTeacherInfo(Teacher teacher) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Course> getAssignedCourses(Teacher teacher) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Student getStudent(Payment payment) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double getPaymentAmount(Payment payment) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public java.sql.Date getPaymentDate(Payment payment) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void assignTeacher(Course course, Teacher teacher) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateCourseInfo(Course course, String courseCode, String courseName, String instructor) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayCourseInfo(Course course) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Student> getEnrollments(Course course) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Teacher getTeacher(Course course) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Student getStudent(Enrollment enrollment) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Course getCourse(Enrollment enrollment) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void enrollStudentInCourse(Student student, Course course) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void assignTeacherToCourse(Teacher teacher, Course course) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void recordPayment(Student student, double amount, Date paymentDate) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void generateEnrollmentReport(Course course) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void generatePaymentReport(Student student) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calculateCourseStatistics(Course course) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Student getStudents(Enrollment enrollment) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean makePayment(int studentId, double amount) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateStudentInfo(int studentId, String firstName, String lastName, String newDateOfBirth,
			String email, String phoneNumber) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String updateTeacherInfo(int teacherId, String newFirstName, String newLastName, Date ndob, String newEmail,
			String newPhoneNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String makePayment(int studentId, double amount, Date paymentDate) {
		return null;
		// TODO Auto-generated method stub
		
	}



	@Override
	public String updateTeacherInfo(int teacherId, String name, String lastName, String email) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public java.sql.Date getPaymentDate() {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public void updateCourseInfo(Course course, String courseName, int credits) {
		// TODO Auto-generated method stub
		
	}

	
}
