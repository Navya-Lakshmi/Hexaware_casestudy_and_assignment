package dao;

import java.util.Date;
import java.util.List;

import entity.Course;
import entity.Enrollment;
import entity.Payment;
import entity.Student;
import entity.Teacher;


public interface ServiceProvider extends StudentService,TeacherService,PaymentService,CourseService,EnrollmentService,sis {
	interface StudentService  {
		 void enrollInCourse(Student student, Course course);
		 String updateStudentInfo(Student student, String firstName, String lastName, Date dateOfBirth, String email, String phoneNumber);
		 void makePayment(Student student, double amount, Date paymentDate);
		 void displayStudentInfo(Student student);
		 List<Course> getEnrolledCourses(Student student);
		 List<Payment> getPaymentHistory(Student student);
		}
	interface TeacherService  {
		 void updateTeacherInfo(Teacher teacher, String name,String lastName, String email);
		 void displayTeacherInfo(Teacher teacher);
		 List<Course> getAssignedCourses(Teacher teacher);
		}
	interface PaymentService{
		 Student getStudent(Payment payment);
		 double getPaymentAmount(Payment payment);
		 Date getPaymentDate(Payment payment);
		}
	interface CourseService {
		 void assignTeacher(Course course, Teacher teacher);
		 void updateCourseInfo(Course course, String courseCode, String courseName, String instructor);
		 void displayCourseInfo(Course course);
		 List<Student> getEnrollments(Course course);
		 Teacher getTeacher(Course course);
		}
	interface EnrollmentService {
		 Student getStudent(Enrollment enrollment);
		 Course getCourse(Enrollment enrollment);
		}
	interface sis {
		 void enrollStudentInCourse(Student student, Course course);
		 void assignTeacherToCourse(Teacher teacher, Course course);
		 void recordPayment(Student student, double amount, Date paymentDate);
		 void generateEnrollmentReport(Course course);
		 void generatePaymentReport(Student student);
		 void calculateCourseStatistics(Course course);
		}
}

