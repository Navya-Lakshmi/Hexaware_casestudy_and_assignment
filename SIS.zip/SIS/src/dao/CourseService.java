package dao;

import java.util.Date;
import java.util.List;

import entity.Course;
import entity.Enrollment;
import entity.Student;
import entity.Teacher;
import exception.CourseNotFoundException;
import exception.TeacherNotFoundException;

public interface CourseService {
	 void assignTeacher(Course course, Teacher teacher) throws CourseNotFoundException, TeacherNotFoundException;
	 void updateCourseInfo(Course course, String courseCode, String courseName, String instructor);
	 void displayCourseInfo(Course course);
	 List<Student> getEnrollments(Course course);
	 Teacher getTeacher(Course course);
	Student getStudent(Enrollment enrollment);
	String updateStudentInfo(int studentId, String firstName, String lastName, Date dateOfBirth, String email,
			String phoneNumber);
	void updateCourseInfo(Course course, String courseName, int credits);
	
	}
