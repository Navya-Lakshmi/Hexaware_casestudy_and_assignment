package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import entity.Course;
import entity.Enrollment;
import entity.Student;
import entity.Teacher;
import exception.CourseNotFoundException;
import exception.TeacherNotFoundException;

public class CourseServiceImpl implements CourseService {
	private Connection conn;
	Course course = new Course();
	Teacher teacher = new Teacher();
	public CourseServiceImpl() {
	conn = Util.DBConnUtil.getConnection();
	}

	
	@Override
	public void assignTeacher(Course course, Teacher teacher) throws CourseNotFoundException, TeacherNotFoundException {
	    // Check if the teacher exists before assigning them to a course
	    if (!isTeacherExists(teacher.getTeacherID())) {
	        throw new TeacherNotFoundException("Teacher does not exist in the system.");
	    }

	    // Check if the course exists before assigning a teacher
	    if (!isCourseExists(course.getCourseID())) {
	        throw new CourseNotFoundException("Course does not exist in the system.");
	    }

	    String query = "UPDATE courses SET teacher_id = ? WHERE course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(query)) {
	        preparedStatement.setInt(1, teacher.getTeacherID());
	        preparedStatement.setInt(2, course.getCourseID());

	        int rowsAffected = preparedStatement.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Teacher assigned to the course successfully.");
	        } else {
	            System.out.println("Failed to assign teacher to the course.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	// Method to check if the teacher exists
	private boolean isTeacherExists(int teacherId) {
	    String checkTeacherQuery = "SELECT COUNT(*) AS count FROM teachers WHERE teacher_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(checkTeacherQuery)) {
	        preparedStatement.setInt(1, teacherId);

	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            if (resultSet.next()) {
	                int count = resultSet.getInt("count");
	                return count > 0;
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return false;
	}


	// Method to check if the course exists
	private boolean isCourseExists(int courseId) {
	    String checkCourseQuery = "SELECT COUNT(*) AS count FROM courses WHERE course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(checkCourseQuery)) {
	        preparedStatement.setInt(1, courseId);

	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            if (resultSet.next()) {
	                int count = resultSet.getInt("count");
	                return count > 0;
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return false;
	}


	

	@Override
	public void updateCourseInfo(Course course,  String courseName,int credits) {
	    String updateCourseQuery = "UPDATE courses SET  course_name = ?, credits = ? WHERE course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(updateCourseQuery)) {
	        
	        preparedStatement.setString(1, courseName);
	        preparedStatement.setInt(2, credits);
	        preparedStatement.setInt(3, course.getCourseID());

	        int rowsAffected = preparedStatement.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Course information updated successfully.");
	        } else {
	            System.out.println("Failed to update course information.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}


	@Override
	public void displayCourseInfo(Course course) {
	    String selectCourseQuery = "SELECT * FROM courses WHERE course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectCourseQuery)) {
	        preparedStatement.setInt(1, course.getCourseID());

	        ResultSet resultSet = preparedStatement.executeQuery();

	        if (resultSet.next()) {
	            System.out.println("Course ID: " + resultSet.getInt("course_id"));
	           
	            System.out.println("Course Name: " + resultSet.getString("course_name"));
	            System.out.println("Credits: " + resultSet.getInt("credits"));
	            // Add more fields as needed
	        } else {
	            System.out.println("Course not found.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}


	@Override
	public List<Student> getEnrollments(Course course) {
	    List<Student> enrolledStudents = new ArrayList<>();
	    String selectEnrollmentsQuery = "SELECT students.* FROM students " +
	                                    "JOIN enrollments ON students.student_id = enrollments.student_id " +
	                                    "WHERE enrollments.course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectEnrollmentsQuery)) {
	        preparedStatement.setInt(1, course.getCourseID());

	        ResultSet resultSet = preparedStatement.executeQuery();

	        while (resultSet.next()) {
	            Student student = new Student();
	            student.setStudentID(resultSet.getInt("student_id"));
	            student.setFirstName(resultSet.getString("first_name"));
	            student.setLastName(resultSet.getString("last_name"));
	            student.setDateOfBirth(resultSet.getDate("date_of_birth").toLocalDate());
	            student.setEmail(resultSet.getString("email"));
	            student.setPhoneNumber(resultSet.getString("phone_number"));
	            // Add more fields as needed

	            enrolledStudents.add(student);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return enrolledStudents;
	}


	@Override
	public Teacher getTeacher(Course course) {
	    Teacher teacher = null;
	    String selectTeacherQuery = "SELECT teacher.* FROM teacher " +
	                               "JOIN courses ON teacher.teacher_id = courses.teacher_id " +
	                               "WHERE courses.course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectTeacherQuery)) {
	        preparedStatement.setInt(1, course.getCourseID());

	        ResultSet resultSet = preparedStatement.executeQuery();

	        if (resultSet.next()) {
	            teacher = new Teacher();
	            teacher.setTeacherID(resultSet.getInt("teacher_id"));
	            teacher.setFirstName(resultSet.getString("first_name"));
	            teacher.setLastName(resultSet.getString("last_name"));
	            teacher.setEmail(resultSet.getString("email"));
	            // Add more fields as needed
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return teacher;
	}

	@Override
	public Student getStudent(Enrollment enrollment) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateStudentInfo(int studentId, String firstName, String lastName, Date dateOfBirth, String email,
			String phoneNumber) {
		// TODO Auto-generated method stub
		return null;
		
		
	}

	@Override
	public void updateCourseInfo(Course course, String courseCode, String courseName, String instructor) {
		// TODO Auto-generated method stub
		
	}


}
