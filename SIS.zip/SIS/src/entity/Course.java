package entity;

public class Course {
    private int courseID;
    private String courseName;
    private int credits;
    
	private int int1;
	private String teacher;
	private int int2;

    // Constructor
    public Course(int courseID, String courseName, int credits) {
        super();
    	this.courseID = courseID;
        this.courseName = courseName;
        
        this.credits = credits;
    }

    public Course() {
		// TODO Auto-generated constructor stub
	}

	// Getters and setters
    public int getCourseID() {
        return courseID;
    }

    public void setCourseID(int courseID) {
        this.courseID = courseID;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

  

   

	
	public int getCredits() {
		return int1;
	}
	public void setCredits(int int1) {
		// TODO Auto-generated method stub
		this.int1=int1;
	}

	public void setInstructorName(Teacher teacher2) {
		// TODO Auto-generated method stub
		
	}

	public void setTeacherId(int int2) {
		// TODO Auto-generated method stub
		this.int2=int2;
	}
	public int getTeacherId() {
		return int2;
	}

}