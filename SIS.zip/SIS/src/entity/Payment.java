package entity;

import java.util.Date;

public class Payment {
    private int paymentID;
    private int studentID;  // Reference to a Student
    private double amount;
    private Date paymentDate;
    public Payment() {
    	
    }

    // Constructor
    public Payment(int paymentID, int studentID, double amount, Date paymentDate) {
         super();
    	this.paymentID = paymentID;
        this.studentID = studentID;
        this.amount = amount;
        this.paymentDate = paymentDate;
    }

    // Getters and setters
    public int getPaymentID() {
        return paymentID;
    }

    public void setPaymentID(int paymentID) {
        this.paymentID = paymentID;
    }

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    
}
