

package util;

import java.util.Properties;

public class DBPropertyUtil {

    public static String getConnectionString() {
        Properties properties = new Properties();
        properties.setProperty("db.url", "jdbc:mysql://localhost:3306/cars?useSSL=false&user=root&password=navya&allowPublicKeyRetrieval=true");

        String url = properties.getProperty("db.url", "");

        return url;
    }
}
/*
package util;

import java.util.Properties;

public class DBPropertyUtil {
	
	public static String getConnectionString() {
		
        Properties properties = new Properties();
        properties.setProperty("db.url", "jdbc:mysql://localhost:3306/cars");
        properties.setProperty("db.user", "root");
        properties.setProperty("db.password", "Navya&02");
        String url = properties.getProperty("db.url", "");
        String user = properties.getProperty("db.user", "");
        String password = properties.getProperty("db.password", "");
        return url +"?useSSL=false&user=" + user + "&password=" + password;
    }

}*/