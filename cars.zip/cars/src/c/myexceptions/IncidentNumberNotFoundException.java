package c.myexceptions;

public class IncidentNumberNotFoundException extends Exception{
	
	public String toString(){
		return "Incident Number Not Found in Db";
		
	}
}